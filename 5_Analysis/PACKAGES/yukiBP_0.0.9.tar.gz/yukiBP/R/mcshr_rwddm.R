#' Title
#'
#' @param list list
#' @param Target target
#' @param Paper_ID Paper_ID
#'
#' @return 结果
#' @export 结果
#'
mcshr_rwddm <- function(list, Target, Paper_ID) {
  
  r_values_v <- list()
  r_values_z <- list()
  
  for(j in 1:length(list)) {
    
    ################################################################################
    
    SPE_half_1 <- list[[j]][[1]] %>%
      # RWiener::wdm 只识别lower upper
      dplyr::mutate(ACC = case_when(ACC == 0 ~ "lower",
                                    ACC == 1 ~ "upper")) %>%
      # wdm每次只接受一个实验条件
      dplyr::group_by(Subject, Matching, Identity, Session) %>%
      dplyr::group_split() %>%
      # 执行wdm，然后将分割的结果重新组合
      base::lapply(., function(df) { 
        #############################Core Codes#################################
        temp <- RWiener::wdm(df, yvar = c("RT_sec", "ACC"))
        #############################Core Codes#################################
        result <- data.frame(df$Subject[1], df$Matching[1], df$Identity[1], df$Session[1], 
                             temp$coefficients[1], temp$coefficients[2], temp$coefficients[3], temp$coefficients[4])
        colnames(result) <- c("Subject", "Matching", "Identity", "Session", 
                              "a", "t", "z", "v")
        rownames(result) <- NULL
        return(result)
      }) %>%
      base::do.call(rbind, .)
    
    SPE_half_2 <- list[[j]][[2]] %>%
      # RWiener::wdm 只识别lower upper
      dplyr::mutate(ACC = case_when(ACC == 0 ~ "lower",
                                    ACC == 1 ~ "upper")) %>%
      # wdm每次只接受一个实验条件
      dplyr::group_by(Subject, Matching, Identity, Session) %>%
      dplyr::group_split() %>%
      # 执行wdm，然后将分割的结果重新组合
      base::lapply(., function(df) { 
        ###############################Core Codes#################################
        temp <- RWiener::wdm(df, yvar = c("RT_sec", "ACC"))
        ###############################Core Codes#################################
        result <- data.frame(df$Subject[1], df$Matching[1], df$Identity[1], df$Session[1], 
                             temp$coefficients[1], temp$coefficients[2], temp$coefficients[3], temp$coefficients[4])
        colnames(result) <- c("Subject", "Matching", "Identity", "Session", 
                              "a", "t", "z", "v")
        rownames(result) <- NULL
        return(result)
      }) %>%
      base::do.call(rbind, .)
    
    ################################################################################ 
    
    SPE_half_1_v <- SPE_half_1 %>%
      dplyr::select(Subject, Session, Matching, Identity, v) %>%
      dplyr::filter(Matching == "Matching") %>%
      tidyr::pivot_wider(names_from = Identity,
                         values_from = v) %>%
      dplyr::mutate(v_SPE_1 = Self - !!sym(Target)) %>%
      dplyr::select(Subject, Session, v_SPE_1)
    
    SPE_half_2_v <- SPE_half_2 %>%
      dplyr::select(Subject, Session, Matching, Identity, v) %>%
      dplyr::filter(Matching == "Matching") %>%
      tidyr::pivot_wider(names_from = Identity,
                         values_from = v) %>%
      dplyr::mutate(v_SPE_2 = Self - !!sym(Target)) %>%
      dplyr::select(Subject, Session, v_SPE_2)
    
    df_cor_v <- SPE_half_1_v %>%
      dplyr::left_join(SPE_half_2_v, by = c("Subject", "Session")) %>%
      dplyr::filter(!is.na(v_SPE_1) & !is.na(v_SPE_2)) %>%
      dplyr::filter(is.finite(v_SPE_1) & is.finite(v_SPE_2))
    
    r_values_v[j] <- cor(df_cor_v[,3], df_cor_v[,4], method = "pearson")
    
    ################################################################################
    
    SPE_half_1_z <- SPE_half_1 %>%
      dplyr::select(Subject, Session, Matching, Identity, z) %>%
      dplyr::filter(Matching == "Matching") %>%
      tidyr::pivot_wider(names_from = Identity,
                         values_from = z) %>%
      dplyr::mutate(z_SPE_1 = Self - !!sym(Target)) %>%
      dplyr::select(Subject, Session, z_SPE_1)
    
    SPE_half_2_z <- SPE_half_2 %>%
      dplyr::select(Subject, Session, Matching, Identity, z) %>%
      dplyr::filter(Matching == "Matching") %>%
      tidyr::pivot_wider(names_from = Identity,
                         values_from = z) %>%
      dplyr::mutate(z_SPE_2 = Self - !!sym(Target)) %>%
      dplyr::select(Subject, Session, z_SPE_2)
    
    df_cor_z <- SPE_half_1_z %>%
      dplyr::left_join(SPE_half_2_z, by = c("Subject", "Session")) %>%
      dplyr::filter(!is.na(z_SPE_1) & !is.na(z_SPE_2)) %>%
      dplyr::filter(is.finite(z_SPE_1) & is.finite(z_SPE_2))
    
    r_values_z[j] <- cor(df_cor_z[,3], df_cor_z[,4], method = "pearson")
  }
  
  # Calculate the mean of the Pearson correlation coefficients
  r_values_vector_v <- unlist(r_values_v)
  r_v <- mean(r_values_vector_v)
  CI_v <- quantile(r_values_vector_v, c(0.025, 0.975))
  
  r_values_vector_z <- unlist(r_values_z)
  r_z <- mean(r_values_vector_z)
  CI_z <- quantile(r_values_vector_z, c(0.025, 0.975))
  
  values_v <- data.frame("Indice" = "RWDDM: v", "r" = r_v, "LLCI" = CI_v[1], "ULCI" = CI_v[2], "Target" = Target, "Paper_ID" = Paper_ID)
  values_z <- data.frame("Indice" = "RWDDM: z", "r" = r_z, "LLCI" = CI_z[1], "ULCI" = CI_z[2], "Target" = Target, "Paper_ID" = Paper_ID)
  values <- rbind(values_v, values_z)
  return(values)
}
