# yukiBP
batch processor of  splithalf reliability and icc

可以用来批量计算分半后数据的信度  
需要配合yukiSH来使用  
而且数据格式必须是Subject, Matching, Identity, Session, RT_ms, RT_sec, ACC

可以计算RT, ACC, d-prime, eff, ezddm_v, ezddm_z, RWiener_v, RWiener_z

